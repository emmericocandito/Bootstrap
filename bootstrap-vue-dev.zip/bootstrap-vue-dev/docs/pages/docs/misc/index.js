// Add redirect from old URL to new one
// @vue/component
export default {
  fetch({ redirect }) {
    redirect('/docs/reference')
  }
}
