import Vue from 'vue'
import { BootstrapVue, BootstrapVueIcons } from '../../src'

Vue.use(BootstrapVue)
Vue.use(BootstrapVueIcons)
