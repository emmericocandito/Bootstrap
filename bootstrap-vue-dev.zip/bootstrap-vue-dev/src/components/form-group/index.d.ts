//
// Form Group
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const FormGroupPlugin: BvPlugin

// Component: b-form-group
export declare class BFormGroup extends BvComponent {}
