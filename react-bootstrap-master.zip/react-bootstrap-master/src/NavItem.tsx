import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('nav-item');
