import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('form-floating');
