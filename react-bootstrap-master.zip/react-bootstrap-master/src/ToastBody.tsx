import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('toast-body');
