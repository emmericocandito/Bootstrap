import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('card-group');
