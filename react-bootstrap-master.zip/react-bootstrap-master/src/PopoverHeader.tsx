import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('popover-header');
