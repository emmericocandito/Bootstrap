import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('offcanvas-body');
