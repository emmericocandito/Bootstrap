import createWithBsPrefix from './createWithBsPrefix';

export default createWithBsPrefix('tab-content');
