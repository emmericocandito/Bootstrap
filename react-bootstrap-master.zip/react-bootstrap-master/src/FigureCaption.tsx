import createWithBsPrefix from './createWithBsPrefix';

const FigureCaption = createWithBsPrefix('figure-caption', {
  Component: 'figcaption',
});

export default FigureCaption;
