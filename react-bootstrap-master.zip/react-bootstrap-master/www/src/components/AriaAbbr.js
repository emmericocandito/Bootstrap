export default function AriaAbbr() {
  return <abbr title="Accessible Rich Internet Applications">ARIA</abbr>;
}
