<Card>
  <Card.Body>This is some text within a card body.</Card.Body>
</Card>;
