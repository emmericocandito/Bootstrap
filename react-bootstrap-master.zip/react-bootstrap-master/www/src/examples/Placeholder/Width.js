<>
  <Placeholder xs={6} />
  <Placeholder className="w-75" /> <Placeholder style={{ width: '25%' }} />
</>;
