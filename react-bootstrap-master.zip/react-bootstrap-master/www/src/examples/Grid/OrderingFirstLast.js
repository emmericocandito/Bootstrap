<Container>
  <Row>
    <Col xs={{ order: 'last' }}>First, but last</Col>
    <Col xs>Second, but unordered</Col>
    <Col xs={{ order: 'first' }}>Third, but first</Col>
  </Row>
</Container>;
