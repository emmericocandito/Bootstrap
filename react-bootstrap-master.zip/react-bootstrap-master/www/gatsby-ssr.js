// prevent FontAwesome icons' flash from a very large one down to a properly sized one
require('@fortawesome/fontawesome-svg-core/styles.css');

exports.wrapPageElement = require('./src/wrap-page');
